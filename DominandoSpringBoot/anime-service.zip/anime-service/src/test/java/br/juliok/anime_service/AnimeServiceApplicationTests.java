package br.juliok.anime_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
